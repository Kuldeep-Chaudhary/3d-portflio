import { useGLTF } from '@react-three/drei'
import { useEffect } from 'react'
import { easing } from 'maath'
import '@/shaders/RevealMaterial'

export function RevealingGLTF({ url }) {
  const { scene } = useGLTF(url)
  const materialRef = useRef()

  // Start reveal animation
  useEffect(() => {
    const timeout = setTimeout(() => {
      setStartReveal(true)
    }, 1000)
    return () => clearTimeout(timeout)
  }, [])

  useFrame((state, delta) => {
    if (startReveal && materialRef.current) {
      easing.damp(materialRef.current, 'revealProgress', 50, 1.5, delta)
    }
  })

  // Replace material on all meshes
  useEffect(() => {
    scene.traverse((child) => {
      if (child.isMesh) {
        child.material = new THREE.ShaderMaterial({
          vertexShader: RevealMaterial.vertexShader,
          fragmentShader: RevealMaterial.fragmentShader,
          uniforms: RevealMaterial.uniforms,
          transparent: true,
        })
        materialRef.current = child.material
      }
    })
  }, [scene])

  return <primitive object={scene} />
}
