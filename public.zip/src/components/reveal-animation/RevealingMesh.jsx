// components/RevealingMesh.jsx
'use client'
import { useEffect, useRef, useState } from 'react'
import { useFrame } from '@react-three/fiber'
import './RevealMaterial'
import { easing } from 'maath'
import * as THREE from 'three'

export default function RevealingMesh({
  geometry = 'sphere',    // 'box', 'plane', etc.
  args = [1, 16, 16],      // geometry args
  color = '#333',
  children,               // optional nested stuff
  ...props                // position, rotation, scale, shadows etc.
}) {
  const materialRef = useRef()
  const [startReveal, setStartReveal] = useState(false)

  useEffect(() => {
    const timeout = setTimeout(() => {
      setStartReveal(true)
    }, 1000)
    return () => clearTimeout(timeout)
  }, [])

  useFrame((_, delta) => {
    if (startReveal && materialRef.current) {
      easing.damp(materialRef.current, 'revealProgress', 50, 1.5, delta)
    }
  })

  // Dynamically choose geometry
  const GeometryType = {
    box: <boxGeometry args={args} />,
    sphere: <sphereGeometry args={args} />,
    plane: <planeGeometry args={args} />,
    cylinder: <cylinderGeometry args={args} />,
    torus: <torusGeometry args={args} />,
    cone: <coneGeometry args={args} />,
  }[geometry] || <sphereGeometry args={args} /> // default to sphere

  return (
    <mesh {...props}>
      {GeometryType}
      <revealMaterial ref={materialRef} color={color} />
      {children}
    </mesh>
  )
}
