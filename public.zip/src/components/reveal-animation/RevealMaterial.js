// components/RevealMaterial.js
import * as THREE from 'three'
import { extend } from '@react-three/fiber'

class RevealMaterial extends THREE.MeshStandardMaterial {
  constructor(parameters = {}) {
    super(parameters)

    this.uniforms = {
      uRevealProgress: { value: 0.0 },
    }

    this.onBeforeCompile = (shader) => {
      shader.uniforms.uRevealProgress = this.uniforms.uRevealProgress

      // Add varying to pass world position
      shader.vertexShader = shader.vertexShader.replace(
        '#include <common>',
        `
        #include <common>
        varying vec3 vWorldPosition;
        `
      )

      shader.vertexShader = shader.vertexShader.replace(
        '#include <project_vertex>',
        `
        #include <project_vertex>
        vec4 worldPos = modelMatrix * vec4(position, 1.0);
        vWorldPosition = worldPos.xyz;
        `
      )

      // Add uniform and logic to discard pixels outside reveal
      shader.fragmentShader = shader.fragmentShader.replace(
        '#include <common>',
        `
        #include <common>
        uniform float uRevealProgress;
        varying vec3 vWorldPosition;
        `
      )

      shader.fragmentShader = shader.fragmentShader.replace(
        '#include <dithering_fragment>',
        `
        float distanceFromCenter = length(vWorldPosition.xz);
        if (distanceFromCenter > uRevealProgress) discard;

        #include <dithering_fragment>
        `
      )
    }
  }

  get revealProgress() {
    return this.uniforms.uRevealProgress.value
  }

  set revealProgress(val) {
    this.uniforms.uRevealProgress.value = val
  }
}

extend({ RevealMaterial })
