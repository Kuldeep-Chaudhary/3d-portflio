// 'use client'

// import { useRef, useState, useEffect } from 'react'
// import { useThree, useFrame } from '@react-three/fiber'
// import { OrbitControls } from '@react-three/drei'
// import * as THREE from 'three'

// export default function CameraControl({ carRef }) {
//   const { camera } = useThree()
//   const orbitRef = useRef()
//   const [followMode, setFollowMode] = useState(false)

//   // Toggle follow mode with Ctrl + C
//   useEffect(() => {
//     const toggleFollow = (e) => {
//       if (e.ctrlKey && e.key.toLowerCase() === 'c') {
//         setFollowMode((prev) => !prev)
//       }
//     }
//     window.addEventListener('keydown', toggleFollow)
//     return () => window.removeEventListener('keydown', toggleFollow)
//   }, [])

//   useFrame((state, delta) => {
//     if (!followMode || !carRef?.current) return

//     const carPos = carRef.current.translation()
//     const carRot = carRef.current.rotation()

//     if (!carPos || !carRot) return

//     const carPosition = new THREE.Vector3(carPos.x, carPos.y, carPos.z)
//     const carQuaternion = new THREE.Quaternion(carRot.x, carRot.y, carRot.z, carRot.w)

//     // Calculate camera position behind the car
//     const behindOffset = new THREE.Vector3(0, 2, 8).applyQuaternion(carQuaternion)
//     const desiredCameraPos = carPosition.clone().add(behindOffset)

//     // Smoothly interpolate camera position
//     camera.position.lerp(desiredCameraPos, 0.1)

//     // Look slightly above the car for better cinematic view
//     const lookAtTarget = carPosition.clone().add(new THREE.Vector3(0, 1.5, 0))
//     camera.lookAt(lookAtTarget)
//   })

//   return !followMode ? <OrbitControls ref={orbitRef} /> : null
// }




import { useEffect, useRef, useState } from 'react'
import { useThree, useFrame } from '@react-three/fiber'
import * as THREE from 'three'

export default function CameraControl({ carRef }) {
  const { camera, scene } = useThree()
  const [followMode, setFollowMode] = useState(false)

  const smoothedCamPos = useRef(new THREE.Vector3())
  const smoothedLookAt = useRef(new THREE.Vector3())

  const followTarget = useRef(new THREE.Object3D())

  const defaultCameraPos = new THREE.Vector3(0, 10, 20)
  const defaultLookAt = new THREE.Vector3(0, 0, 0)

  useEffect(() => {
    scene.add(followTarget.current)
  }, [scene])

  useEffect(() => {
    const handleKeyDown = (e) => {
      if (e.ctrlKey && e.key.toLowerCase() === 'c') {
        setFollowMode((prev) => !prev)
      }
    }

    window.addEventListener('keydown', handleKeyDown)
    return () => window.removeEventListener('keydown', handleKeyDown)
  }, [])

  useEffect(() => {
    if (!followMode) {
      camera.position.copy(defaultCameraPos)
      camera.lookAt(defaultLookAt)
    }
  }, [followMode])

  useFrame((state, delta) => {
    if (!followMode || !carRef.current) return

    const car = carRef.current
    const pos = car.translation()
    const rot = car.rotation()

    const quaternion = new THREE.Quaternion(rot.x, rot.y, rot.z, rot.w)
    const forward = new THREE.Vector3(0, 0, 1).applyQuaternion(quaternion).normalize()

    followTarget.current.position.lerp(new THREE.Vector3(pos.x, pos.y, pos.z), 0.15)

    const camOffset = forward.clone().multiplyScalar(6).add(new THREE.Vector3(0, 2.5, 0))
    const targetCamPos = followTarget.current.position.clone().add(camOffset)
    const targetLook = followTarget.current.position.clone().add(new THREE.Vector3(0, 1, 0))

    const lerpAlpha = THREE.MathUtils.clamp(1 - Math.pow(0.01, delta), 0.01, 1)

    smoothedCamPos.current.lerp(targetCamPos, lerpAlpha)
    smoothedLookAt.current.lerp(targetLook, lerpAlpha)

    camera.position.copy(smoothedCamPos.current)
    camera.lookAt(smoothedLookAt.current)
  })

  return null
}
