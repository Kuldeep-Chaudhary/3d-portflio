import { Physics, useRapier } from '@react-three/rapier'
import { useEffect, useState } from 'react'

export default function PhysicsWrapper({ children }) {
  const [gravity, setGravity] = useState([0, -2, 0]) // Slower drop

  useEffect(() => {
    const timeout = setTimeout(() => {
      setGravity([0, -9.81, 0]) // Normal gravity  after 2s
    }, 500)

    return () => clearTimeout(timeout)
  }, [])

  return <Physics gravity={gravity}>{children}</Physics>
}
