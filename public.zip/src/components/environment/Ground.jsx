'use client'
import '@/shaders/RevealMaterial'
import { RigidBody } from '@react-three/rapier'
import RevealingMesh from '../reveal-animation/RevealingMesh'

export const GROUND_SIZE = [50, 50]
export default function Ground() {
  return (
    <RigidBody type="fixed" colliders="cuboid" friction={1} restitution={0.5}>
      <RevealingMesh  geometry='box' position={[0, 0, 0]} args={[50, 0.1 , 50]}color="#444"/>
    </RigidBody>
  )
}
