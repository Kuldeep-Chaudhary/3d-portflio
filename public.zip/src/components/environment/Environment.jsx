// Environment.jsx
import { RigidBody } from "@react-three/rapier";
import { Box, Sphere } from "@react-three/drei";
import * as THREE from "three";
import Ground, { GROUND_SIZE } from "./Ground";
import Wall from "./Wall";
import RevealingMesh from "../reveal-animation/RevealingMesh";

const [width, height] = GROUND_SIZE;

const getWalls = (width, height) => [
  { position: [0, 1, height / 2], size: [width, 2, 1] }, // back
  { position: [0, 1, -height / 2], size: [width, 2, 1] }, // front
  { position: [-width / 2, 1, 0], size: [1, 2, height] }, // left
  { position: [width / 2, 1, 0], size: [1, 2, height] }, // right
];

export default function Environment() {
  return (
    <>
      {/* Ground */}
      <Ground />

      {/* Walls (simple bounding walls) */}

      {/* walls */}
      {getWalls(width, height).map((wall, i) => (
        <Wall key={i} position={wall.position} size={wall.size} />
      ))}

      {/* Ramps */}
      <RigidBody type="fixed" colliders="cuboid" friction={1} restitution={0.5}>
        <RevealingMesh
          geometry="box"
          position={[5, 0.25, -10]}
          args={[4, 0.2, 3]}
          rotation={[-Math.PI / 18, 0, 0]}
          color="#000"
        />
      </RigidBody>
      <RigidBody type="fixed" colliders="cuboid" friction={1} restitution={0.5}>
        <RevealingMesh
          geometry="box"
          position={[5, 0.25, -7.2 ]}
          args={[4, 0.2, 3]}
          rotation={[Math.PI / 18, 0, 0]}
          color="#000"
        />
      </RigidBody>

      {/* Balls */}

      {Array.from({ length: 10 }).map((_, i) => (
        <RigidBody
          key={i}
          type="dynamic"
          colliders="ball"
          restitution={0.7}
          position={[Math.random() * 20 - 10, 1, Math.random() * 20 - 10]}
        >
          <RevealingMesh
            geometry="sphere"
            args={[0.1, 16, 16]}
            color="#fff"
            castShadow
            receiveShadow
          />
        </RigidBody>
      ))}
    </>
  );
}
