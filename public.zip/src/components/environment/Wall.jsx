import { RigidBody } from "@react-three/rapier"
import RevealingMesh from "../reveal-animation/RevealingMesh"

export default function Wall({ position, size}) {
  return (
    <RigidBody type="fixed" >
      <RevealingMesh geometry="box" position={position} args={size} color="#444"/>
    </RigidBody>
  )
}
