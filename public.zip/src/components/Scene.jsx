"use client";

import { Canvas } from "@react-three/fiber";
import { OrbitControls } from "@react-three/drei";
import { Suspense, useRef } from "react";
// import Ground from "./environment/Ground";
import { Physics } from '@react-three/rapier'
import CarControl from "./car/CarControl";
import PhysicsWrapper from "./PhysicsWrapper";

import { KeyboardControls } from '@react-three/drei'
import CameraControl from "./camera/CameraController";
import Environment from "./environment/Environment";

export default function Scene() {
  const carRef = useRef()
  return (
    <div className="w-screen h-screen">
      <KeyboardControls
        map={[
          { name: 'forward', keys: ['ArrowUp', 'w'] },
          { name: 'backward', keys: ['ArrowDown', 's'] },
          { name: 'left', keys: ['ArrowLeft', 'a'] },
          { name: 'right', keys: ['ArrowRight', 'd'] },
          { name: 'reset', keys: ['r', 'R'] },
        ]}
      >
        <Canvas
          camera={{ position: [0, 5, 10], fov: 45 }}
          shadows
          dpr={[1, 2]}
          gl={{ antialias: true }}
          onCreated={({ gl }) => {
            gl.setClearColor("#000")
          }}
        >
          {/* Lights */}
          <ambientLight intensity={0.4} />
          <directionalLight
            position={[5, 10, 5]}
            intensity={1}
            castShadow
            shadow-mapSize-width={1024}
            shadow-mapSize-height={1024}
          />

          <Suspense fallback={null}>
            <Physics>
              <CarControl carRef={carRef}  />
              <Environment/>
              {/* <Ground /> */}
            </Physics>
          </Suspense>

              <CameraControl carRef={carRef} />
          <OrbitControls />
        </Canvas>
      </KeyboardControls>
    </div>
  )
}