
import { useGLTF } from '@react-three/drei'

export default function Car() {
  const gltf = useGLTF('/cars/cyberpunk_car.compressed.glb')
    return(
        <primitive object={gltf.scene} scale={0.003}/>
    );
};