'use client'

import { useRef } from 'react'
import { RigidBody } from '@react-three/rapier'
import Car from './Car'
import { useFrame } from '@react-three/fiber'
import { useKeyboardControls } from '@react-three/drei'

export default function CarControl({ carRef }) {
  const forward = useKeyboardControls((state) => state.forward)
  const backward = useKeyboardControls((state) => state.backward)
  const left = useKeyboardControls((state) => state.left)
  const right = useKeyboardControls((state) => state.right)
  const resetKey = useKeyboardControls((state) => state.reset) // For R key

  const upsideDownTime = useRef(0)

useFrame((state, delta) => {
  const body = carRef.current
  if (!body) return

  const rotation = body.rotation()
  const velocity = body.linvel()

  const upY = 1 - 2 * (rotation.x * rotation.x + rotation.z * rotation.z)
  const isFlipped = upY < 0.3
  const isAirborne = Math.abs(velocity.y) > 0.1  // 👈 new line
  const shouldFlip = isFlipped && (upsideDownTime.current += delta) > 3 || resetKey

  if (shouldFlip) {
    const pos = body.translation()
    body.setTranslation({ x: pos.x, y: pos.y + 1, z: pos.z }, true)
    body.setLinvel({ x: 0, y: 0, z: 0 }, true)
    body.setAngvel({ x: 0, y: 0, z: 0 }, true)
    body.setRotation({ x: 0, y: rotation.y, z: 0, w: 1 }, true)
    upsideDownTime.current = 0
  } else if (!isFlipped) {
    upsideDownTime.current = 0
  }

  // ⛔️ Prevent control when airborne or upside down
  if (isAirborne || isFlipped) return

  const impulseStrength = 5
  const turningStrength = 0.7

  const eulerY = quaternionToEulerY(rotation)
  const forwardVector = {
    x: -Math.sin(eulerY),
    y: 0,
    z: -Math.cos(eulerY),
  }

  if (forward) {
    body.applyImpulse(
      {
        x: forwardVector.x * impulseStrength * delta,
        y: 0,
        z: forwardVector.z * impulseStrength * delta,
      },
      true
    )
  }

  if (backward) {
    body.applyImpulse(
      {
        x: -forwardVector.x * impulseStrength * delta,
        y: 0,
        z: -forwardVector.z * impulseStrength * delta,
      },
      true
    )
  }

  if (left) {
    body.applyTorqueImpulse({ x: 0, y: turningStrength * delta, z: 0 })
  }

  if (right) {
    body.applyTorqueImpulse({ x: 0, y: -turningStrength * delta, z: 0 })
  }
})


  function quaternionToEulerY(q) {
    const siny_cosp = 2 * (q.w * q.y + q.z * q.x)
    const cosy_cosp = 1 - 2 * (q.y * q.y + q.z * q.z)
    return Math.atan2(siny_cosp, cosy_cosp)
  }

  return (
    <RigidBody
      ref={carRef}
      type="dynamic"
      colliders="hull"
      position={[0, 2, 0]}
      friction={1}
      restitution={0.5}
      linearDamping={0.9}
      angularDamping={1.5}
      mass={5}
    >
      <Car />
    </RigidBody>
  )
}
