import Scene from "@/components/Scene";
import { KeyboardControls } from '@react-three/drei'

export default function Home() {
  
  return (
    <>
       <Scene/>
    </>
  );
}
